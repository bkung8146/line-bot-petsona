from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import MessageEvent, ImageMessage, ImageSendMessage
import boto3
import os
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
# Import the Python SDK
import google.generativeai as genai
# Used to securely store your API key
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError

from linebot import LineBotApi, WebhookHandler
from linebot.models import (
    CarouselColumn, CarouselTemplate, MessageAction, TemplateSendMessage
)
import boto3
from django.conf import settings
from linebot.models import MessageEvent, TextMessage, CarouselTemplate, CarouselColumn, TemplateSendMessage, URITemplateAction
dynamodb = boto3.resource('dynamodb', region_name='ap-southeast-2')
table = dynamodb.Table('petsona-chat')

from linebot.models import MessageEvent, TextMessage, TextSendMessage
genai.configure(api_key='AIzaSyBEcayu9TRihdoQfQk_YC-bwKuyepJoOhk')
file = open('bot\petsona.txt', 'r',encoding='utf-8')
model = genai.GenerativeModel('gemini-1.5-flash',system_instruction=file.read())
from django.http import JsonResponse

LINE_CHANNEL_ACCESS_TOKEN = os.getenv('LINE_CHANNEL_ACCESS_TOKEN')
LINE_CHANNEL_SECRET = os.getenv('LINE_CHANNEL_SECRET')

line_bot_api = LineBotApi(LINE_CHANNEL_ACCESS_TOKEN)
handler = WebhookHandler(LINE_CHANNEL_SECRET)

from gradio_client import Client, handle_file

client = Client("Natthanarong/petsona-cat-api")

@csrf_exempt
def callback(request):
    if request.method == 'POST':
        signature = request.META['HTTP_X_LINE_SIGNATURE']
        body = request.body.decode('utf-8')

        try:
            handler.handle(body, signature)
        except InvalidSignatureError:
            return HttpResponse(status=400)

        return HttpResponse(status=200)
    else:
        return HttpResponse(status=405)

@handler.add(MessageEvent, message=TextMessage)
def handle_image_message(event):
    response = table.get_item(
    Key={
        'user_id': event.source.user_id,
    })
    print(response.get('Item',[]))
    print(len(response.get('Item',[])))
    if len(response.get('Item',[])) == 0:
        table.put_item(
        Item={
                'user_id': event.source.user_id,
                'history': [
                    {
                        'role': 'user',
                        'parts':[event.message.text]
                    }
                ],
            }
        )
    else:
        response = table.get_item(
            Key={
                'user_id': event.source.user_id,
            }
        )
        history = response['Item']['history']
        table.update_item(
            Key={
                'user_id': event.source.user_id,
            },
            UpdateExpression='SET history = :val1',
            ExpressionAttributeValues={
                ':val1': history + [{'role': 'user', 'parts':[event.message.text]}]
            }
        )
    user_message = event.message.text
    response = table.get_item(
        Key={
            'user_id': event.source.user_id,
        }
    )
    history = response['Item']['history']
    print(history)
    response_model = model.generate_content(history)
    response = table.get_item(
        Key={
            'user_id': event.source.user_id,
        }
    )
    history = response['Item']['history']
    print(history)
    table.update_item(
        Key={
            'user_id': event.source.user_id,
        },
        UpdateExpression='SET history = :val1',
        ExpressionAttributeValues={
            ':val1': history + [{'role': 'model', 'parts':[response_model.text]}]
        }
    )
    reply_message = TextSendMessage(text=response_model.text)
    line_bot_api.reply_message(event.reply_token, reply_message)

@handler.add(MessageEvent, message=ImageMessage)
def handle_image_message(event):

    # ดึงข้อมูล URL ของรูปภาพที่ส่งมา
    message_id = event.message.id
    message_content = line_bot_api.get_message_content(message_id)

    # เก็บรูปภาพลงในไฟล์ชั่วคราวและบันทึกไปยัง S3
    temp_image_file_path = f'{message_id}.jpg'
    
    # สร้าง ContentFile จาก content ที่ได้จาก line_bot_api
    content_file = ContentFile(b''.join(message_content.iter_content()))

    # บันทึกไฟล์ไปยัง S3
    s3_file_path = default_storage.save(temp_image_file_path, content_file)

    # สร้าง URL สำหรับรูปภาพบน S3
    s3_image_url = default_storage.url(s3_file_path)
    result = client.predict(
        param_0=handle_file(s3_image_url),  
        api_name="/predict"
    )
    # ส่งรูปภาพกลับไปที่ผู้ใช้
    reply_message = TextSendMessage(text=str(result['label']))
    line_bot_api.reply_message(event.reply_token, reply_message)

    